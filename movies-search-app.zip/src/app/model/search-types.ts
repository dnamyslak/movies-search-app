export enum SearchTypes {
  Movie = 'movie',
  Series = 'series',
  Episode = 'episode',
}

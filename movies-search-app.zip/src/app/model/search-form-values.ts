export interface SearchFormValues {
  searchTitle: string;
  searchYear: string;
  searchType: string;
}
